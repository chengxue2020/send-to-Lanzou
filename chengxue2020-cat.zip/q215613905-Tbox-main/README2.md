# TVBoxXD

[![AutoBuildTest](https://github.com/chengxue2020/q215613905-Tbox/actions/workflows/auto_build_with_remark.yml/badge.svg)](https://github.com/chengxue2020/q215613905-Tbox/actions/workflows/auto_build_with_remark.yml)
[![Download](https://img.shields.io/github/v/release/chengxue2020/q215613905-Tbox?color=green&logoColor=green&label=Download&logo=DocuSign)](https://github.com/chengxue2020/q215613905-Tbox/releases)

## Credits
This repo relies on the following third-party projects:
- [CatVodTVOfficial/TVBoxOSC](https://github.com/CatVodTVOfficial/TVBoxOSC)
- [o0HalfLife0o/TVBoxOSC](https://github.com/o0HalfLife0o/TVBoxOSC/releases)
- [chengxue2020/q215613905-Tbox](https://github.com/chengxue2020/q215613905-Tbox) (Updated: 9ad81ce3ad290a47780239aed29b83e4123938d2)
- [q215613905/TVBoxOS](https://github.com/q215613905/TVBoxOS) (Updated: 8b63bf8958d16626ca28e1695eecfa8de22e7628)
- [takagen99/Box](https://github.com/takagen99/Box) (Updated: 677dfb680f146a4b2ead10d0141bc8a68af196f4)
- [FongMi/TV](https://github.com/FongMi/TV) (Updated: 23e8bb2432c361c32641f44622415faa00dd3234)
- [muxd93/TVBoxOS_XD](https://github.com/muxd93/TVBoxOS_XD) (Updated: 41fc69b512b5380a5a37e4885412acadc4ebf31d)
- [muxd93/TVBox_takagen99](https://github.com/muxd93/TVBox_takagen99) (Updated: 0f8f9870b0ee4d1d285a6a62751b608d3fb0e502)
- [Roinlong/TVbox_Mobile](https://github.com/Roinlong/TVbox_Mobile) (Updated: 29ab2b9d4ffc532c8f1541e4e029a247f79cd3a0)
